(function() {
    tinymce.PluginManager.add('embedgd_button', function( editor, url ) {
        editor.addButton( 'embedgd_button', {
            title: objectL10n.int_plgtitle,
            type: 'button',
            icon: 'icon embedgd-icon',
            onclick: function() {
                editor.windowManager.open( {
                    title: objectL10n.int_title,
                    body: [{
                        type: 'textbox',
                        name: 'gd_id',
                        label: objectL10n.int_label,
                        },
                        {
                        type: 'listbox',
                        name: 'gd_type',
                        label: objectL10n.int_select,
                        values : [
                            { text: 'MP3', value: 'mp3' },
                            { text: 'WAV', value: 'wav' },
                            { text: 'WMA', value: 'wma' },
                            { text: 'OGG', value: 'ogg', selected: true }
                        ]
                    }],
                    onsubmit: function( e ) {
                        var id = e.data.gd_id.trim();
                        if (!id || 0 === id.length) return false;
                        var n = id.indexOf("?id=");
                        if (n!=-1) 
                            id = id.substr(n+4);
                        //embed googledrive audio within html5 player
                        editor.insertContent( '<audio controls src="https://docs.google.com/uc?authuser=0&amp;id=' + id + '&amp;type=.' + e.data.gd_type + '"></audio>');
                    }
                });
            },
        });
    });
})();