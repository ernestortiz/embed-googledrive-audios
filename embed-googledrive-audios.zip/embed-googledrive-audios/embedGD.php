<?php
/**
 * Plugin Name: Embed GoogleDrive audios
 * Description: A lazy way to embed audio files from GoogleDrive on your wordpress blog.
 * Version: 1.0
 * Author: Ernesto Ortiz
 * Author URI:
 * License: GNU General Public License v3 or later
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 * Text Domain: embedgdaudio
 * Domain Path: languages
 */

// load plugin text domain
function embedgdaudio_init() {
    load_plugin_textdomain( 'embedgdaudio', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}
add_action('plugins_loaded', 'embedgdaudio_init');

// int language in js
wp_register_script( 'int_handle', '', array(), false, true );
wp_enqueue_script( 'int_handle');
wp_localize_script( 'int_handle', 'objectL10n', array(
    'int_plgtitle' => esc_html__('Embed GD audios','embedgdaudio'),
    'int_title' => esc_html__('Embed GoogleDrive audio','embedgdaudio'),
    'int_label' => esc_html__('Copy the public link of the audio file (or just the ID)','embedgdaudio'),
    'int_select' => esc_html__('Select the format of the audio', 'embedgdaudio'),
)); 

// styles & scripts
function embedgdaudio_scripts() {
    wp_enqueue_style('embedgd_css', plugins_url('/css/style.css', __FILE__));
}
add_action('admin_enqueue_scripts', 'embedgdaudio_scripts');
  
// add mce button
add_action('admin_head', 'embedgd_add_button');
function embedgd_add_button() {
    // check user permissions
    if (!current_user_can('edit_posts') && !current_user_can('edit_pages')) return;
    // only in posts and pages
    // global $typenow;
    //if( ! in_array( $typenow, array( 'post', 'page' ) ) )
    //return;
    // if WYSIWYG is enabled
    if ( get_user_option('rich_editing') == 'true') {
        add_filter("mce_external_plugins", "embedgd_add_plugin");
        add_filter('mce_buttons', 'embedgd_register_button');
    }
}
function embedgd_add_plugin($plugin_array) {
    $plugin_array['embedgd_button'] = plugins_url( '/js/embedGD.js', __FILE__ ); // CHANGE THE BUTTON SCRIPT HERE
    return $plugin_array;
}
function embedgd_register_button($buttons) {
   array_push($buttons, "embedgd_button");
   return $buttons;
}

/** regular FUNCTIONS **/
//include 'functions.php';

/** AJAX FUNCTIONS **/
//include "ajaxes.php";


?>
